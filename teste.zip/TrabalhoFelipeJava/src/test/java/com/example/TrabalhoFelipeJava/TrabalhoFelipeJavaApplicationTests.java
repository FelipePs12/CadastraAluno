package com.example.TrabalhoFelipeJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoFelipeJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
